import { DomFacade } from "../domFacade.js";
import { Empleado } from "../models/empleado.js";
import { Almacenamiento } from "../storage/localStorage.js";
import {
  Filtro,
  FiltrarPorDepartamento,
  FiltrarPorEstado,
  FiltrarPorSenioridad,
  MostrarTodos,
  BuscarPorTexto,
} from "./filtro.js";

export class EmpleadoManager {
  static crearEmpleado(event) {
    event.preventDefault();

    const errores = [];
    const datosEmpleado = DomFacade.obtenerDatos();

    if (datosEmpleado.nombre === "") {
      errores.push("El nombre no puede estar vacío");
    }
    if (datosEmpleado.email === "" || !datosEmpleado.email.includes("@")) {
      errores.push("El email debe ser válido");
    }
    if (datosEmpleado.salario <= 0) {
      errores.push("El salario debe ser mayor a 0");
    }
    if (datosEmpleado.antiguedad < 0) {
      errores.push("La antigüedad no puede ser negativa");
    }

    if (errores.length === 0) {
      const empleado = new Empleado(
        datosEmpleado.nombre,
        datosEmpleado.email,
        datosEmpleado.departamento,
        datosEmpleado.salario,
        datosEmpleado.antiguedad
      );
      Almacenamiento.addLocalStorage(empleado);
      DomFacade.limpiarFormulario();
      EmpleadoManager.renderEmpleados();
    } else {
      alert(errores.join("\n"));
    }
  }

  static renderEmpleados() {
    DomFacade.crearEmpleadoDom(Almacenamiento.obtener());
  }

  static filtrarPorDepartamento() {
    const departamento = DomFacade.obtenerFiltroDepartamento();
    const todosLosEmpleados = Almacenamiento.obtener();

    const filtro = new Filtro();

    if (departamento === "" || departamento === "todos") {
      filtro.setStrategy(new MostrarTodos());
      DomFacade.crearEmpleadoDom(filtro.filtrar(todosLosEmpleados));
    } else {
      filtro.setStrategy(new FiltrarPorDepartamento());
      DomFacade.crearEmpleadoDom(
        filtro.filtrar(todosLosEmpleados, departamento)
      );
    }
  }

  static filtrarPorEstado() {
    const estado = DomFacade.obtenerFiltroEstado();
    const todosLosEmpleados = Almacenamiento.obtener();

    const filtro = new Filtro();

    if (estado === "" || estado === "todos") {
      filtro.setStrategy(new MostrarTodos());
      DomFacade.crearEmpleadoDom(filtro.filtrar(todosLosEmpleados));
    } else {
      filtro.setStrategy(new FiltrarPorEstado());
      DomFacade.crearEmpleadoDom(filtro.filtrar(todosLosEmpleados, estado));
    }
  }

  static filtrarPorSenioridad() {
    const senioridad = DomFacade.obtenerFiltroSenioridad();
    const todosLosEmpleados = Almacenamiento.obtener();

    const filtro = new Filtro();

    if (senioridad === "" || senioridad === "todos") {
      filtro.setStrategy(new MostrarTodos());
      DomFacade.crearEmpleadoDom(filtro.filtrar(todosLosEmpleados));
    } else {
      filtro.setStrategy(new FiltrarPorSenioridad());
      DomFacade.crearEmpleadoDom(filtro.filtrar(todosLosEmpleados, senioridad));
    }
  }

  static buscarEmpleado() {
    const textoBusqueda = DomFacade.obtenerTextoBusqueda();
    const todosLosEmpleados = Almacenamiento.obtener();

    const filtro = new Filtro();

    if (textoBusqueda === "") {
      filtro.setStrategy(new MostrarTodos());
      DomFacade.crearEmpleadoDom(filtro.filtrar(todosLosEmpleados));
    } else {
      filtro.setStrategy(new BuscarPorTexto());
      DomFacade.crearEmpleadoDom(
        filtro.filtrar(todosLosEmpleados, textoBusqueda)
      );
    }
  }

  static toggleEstado(id) {
    const empleados = Almacenamiento.obtener();
    const empleado = empleados.find((e) => e.id === id);

    if (empleado) {
      empleado.activo = !empleado.activo;
      localStorage.setItem("empleados", JSON.stringify(empleados));
      EmpleadoManager.renderEmpleados();
    }
  }

  static eliminarEmpleado(id) {
    const empleados = Almacenamiento.obtener();
    const empleadosActualizados = empleados.filter(
      (empleado) => empleado.id !== id
    );
    localStorage.setItem("empleados", JSON.stringify(empleadosActualizados));
    EmpleadoManager.renderEmpleados();
  }
}
