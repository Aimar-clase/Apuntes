export class Filtro {
  constructor() {
    this.strategy = null;
  }

  setStrategy(strategy) {
    this.strategy = strategy;
  }

  filtrar(empleados, valor) {
    if (!this.strategy) {
      return empleados;
    }
    return this.strategy.filtrar(empleados, valor);
  }
}

export class FiltrarPorDepartamento {
  filtrar(empleados, departamento) {
    if (!empleados || empleados.length === 0) {
      return [];
    }
    return empleados.filter(
      (empleado) => empleado.departamento === departamento
    );
  }
}

export class FiltrarPorEstado {
  filtrar(empleados, estado) {
    if (!empleados || empleados.length === 0) {
      return [];
    }
    if (estado === "activo") {
      return empleados.filter((empleado) => empleado.activo === true);
    } else if (estado === "inactivo") {
      return empleados.filter((empleado) => empleado.activo === false);
    }
    return empleados;
  }
}

export class FiltrarPorSenioridad {
  filtrar(empleados, senioridad) {
    if (!empleados || empleados.length === 0) {
      return [];
    }
    if (senioridad === "senior") {
      return empleados.filter((empleado) => empleado.antiguedad >= 5);
    } else if (senioridad === "junior") {
      return empleados.filter((empleado) => empleado.antiguedad < 5);
    }
    return empleados;
  }
}

export class MostrarTodos {
  filtrar(empleados) {
    return empleados || [];
  }
}

export class BuscarPorTexto {
  filtrar(empleados, texto) {
    if (!empleados || empleados.length === 0) {
      return [];
    }
    const textoBusqueda = texto.toLowerCase();
    return empleados.filter(
      (empleado) =>
        empleado.nombre.toLowerCase().includes(textoBusqueda) ||
        empleado.email.toLowerCase().includes(textoBusqueda) ||
        empleado.departamento.toLowerCase().includes(textoBusqueda)
    );
  }
}
