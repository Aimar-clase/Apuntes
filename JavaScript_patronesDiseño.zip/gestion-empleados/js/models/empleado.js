export class Empleado {
  constructor(nombre, email, departamento, salario, antiguedad) {
    this.id = Date.now();
    this.nombre = nombre;
    this.email = email;
    this.departamento = departamento;
    this.salario = salario;
    this.antiguedad = antiguedad;
    this.activo = true;
    this.fechaRegistro = new Date().toLocaleDateString();
  }

  esSenior() {
    return this.antiguedad >= 5;
  }
}
