import { EmpleadoManager } from "./patterns/empleadoManager.js";

const formulario = document.querySelector("form");
formulario.addEventListener("submit", EmpleadoManager.crearEmpleado);

document.addEventListener("DOMContentLoaded", EmpleadoManager.renderEmpleados);

const filtroDepartamento = document.getElementById("filtroDepartamento");
filtroDepartamento.addEventListener(
  "change",
  EmpleadoManager.filtrarPorDepartamento
);

const filtroEstado = document.getElementById("filtroEstado");
filtroEstado.addEventListener("change", EmpleadoManager.filtrarPorEstado);

const filtroSenioridad = document.getElementById("filtroSenioridad");
filtroSenioridad.addEventListener(
  "change",
  EmpleadoManager.filtrarPorSenioridad
);

const buscador = document.getElementById("buscador");
buscador.addEventListener("input", EmpleadoManager.buscarEmpleado);

window.EmpleadoManager = EmpleadoManager;
