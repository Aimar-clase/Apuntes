export class DomFacade {
  static crearEmpleadoDom(empleados) {
    const visualizadorEmpleados = document.getElementById(
      "visualizadorEmpleados"
    );
    visualizadorEmpleados.innerHTML = "";

    if (!empleados || empleados.length === 0) {
      visualizadorEmpleados.innerHTML = "<p>No hay empleados registrados</p>";
      return;
    }

    for (const key in empleados) {
      let emp = empleados[key];
      let divEmpleado = document.createElement("div");
      divEmpleado.className = "empleado-card";
      divEmpleado.setAttribute("data-departamento", emp.departamento);

      const estadoBadge = emp.activo
        ? '<span class="activo-badge">✅ Activo</span>'
        : '<span class="inactivo-badge">⏸️ Inactivo</span>';

      const seniorBadge =
        emp.antiguedad >= 5
          ? '<span class="senior-badge">⭐ SENIOR</span>'
          : "";

      divEmpleado.innerHTML = `
        ${seniorBadge}
        <h3>${emp.nombre}</h3>
        <p><strong>📧 Email:</strong> ${emp.email}</p>
        <p><strong>🏢 Departamento:</strong> ${emp.departamento}</p>
        <p class="salario"><strong>💰 Salario:</strong> €${emp.salario.toLocaleString()}/año</p>
        <p><strong>📅 Antigüedad:</strong> ${emp.antiguedad} años</p>
        <p><strong>📆 Registro:</strong> ${emp.fechaRegistro}</p>
        <p><strong>Estado:</strong> ${estadoBadge}</p>
      `;

      const checkboxContainer = document.createElement("div");
      checkboxContainer.className = "checkbox-container";

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = emp.activo;
      checkbox.addEventListener("change", () => {
        window.EmpleadoManager.toggleEstado(emp.id);
      });

      checkboxContainer.appendChild(checkbox);
      checkboxContainer.appendChild(
        document.createTextNode(" Empleado Activo")
      );

      const btnEliminar = document.createElement("button");
      btnEliminar.textContent = "🗑️ Eliminar Empleado";
      btnEliminar.addEventListener("click", () => {
        if (confirm(`¿Estás seguro de eliminar a ${emp.nombre}?`)) {
          window.EmpleadoManager.eliminarEmpleado(emp.id);
        }
      });

      divEmpleado.appendChild(checkboxContainer);
      divEmpleado.appendChild(btnEliminar);
      visualizadorEmpleados.appendChild(divEmpleado);
    }
  }

  static obtenerDatos() {
    const nombre = document.getElementById("nombreEmpleado").value;
    const email = document.getElementById("emailEmpleado").value;
    const departamento = document.getElementById("departamentoEmpleado").value;
    const salario = parseFloat(
      document.getElementById("salarioEmpleado").value
    );
    const antiguedad = parseInt(
      document.getElementById("antiguedadEmpleado").value
    );

    return { nombre, email, departamento, salario, antiguedad };
  }

  static obtenerFiltroDepartamento() {
    return document.getElementById("filtroDepartamento").value;
  }

  static obtenerFiltroEstado() {
    return document.getElementById("filtroEstado").value;
  }

  static obtenerFiltroSenioridad() {
    return document.getElementById("filtroSenioridad").value;
  }

  static obtenerTextoBusqueda() {
    return document.getElementById("buscador").value;
  }

  static limpiarFormulario() {
    document.getElementById("nombreEmpleado").value = "";
    document.getElementById("emailEmpleado").value = "";
    document.getElementById("departamentoEmpleado").value = "ventas";
    document.getElementById("salarioEmpleado").value = "";
    document.getElementById("antiguedadEmpleado").value = "";
  }
}
