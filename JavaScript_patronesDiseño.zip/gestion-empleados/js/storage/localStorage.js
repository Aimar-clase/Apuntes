export class Almacenamiento {
  static obtener() {
    return JSON.parse(localStorage.getItem("empleados"));
  }

  static addLocalStorage(empleado) {
    let empleados = this.obtener() || [];
    empleados.push(empleado);
    localStorage.setItem("empleados", JSON.stringify(empleados));
  }
}
