import { ProductManager } from "./patterns/productManager.js";

const formulario = document.querySelector("form");
formulario.addEventListener("submit", ProductManager.crearProducto);

document.addEventListener("DOMContentLoaded", ProductManager.renderProductos);

const filtroCategoria = document.getElementById("filtroCategoria");
filtroCategoria.addEventListener("change", ProductManager.filtrarPorCategoria);

const filtroStock = document.getElementById("filtroStock");
filtroStock.addEventListener("change", ProductManager.filtrarPorStock);

const filtroOferta = document.getElementById("filtroOferta");
filtroOferta.addEventListener("change", ProductManager.filtrarPorOferta);

const buscador = document.getElementById("buscador");
buscador.addEventListener("input", ProductManager.buscarProducto);

window.ProductManager = ProductManager;
