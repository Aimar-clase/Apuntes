export class Almacenamiento {
  static obtener() {
    return JSON.parse(localStorage.getItem("productos"));
  }

  static addLocalStorage(producto) {
    let productos = this.obtener() || [];
    productos.push(producto);
    localStorage.setItem("productos", JSON.stringify(productos));
  }
}
