export class DomFacade {
  static crearProductoDom(productos) {
    const visualizadorProductos = document.getElementById(
      "visualizadorProductos"
    );
    visualizadorProductos.innerHTML = "";

    if (!productos || productos.length === 0) {
      visualizadorProductos.innerHTML = "<p>No hay productos para mostrar</p>";
      return;
    }

    for (const key in productos) {
      let prod = productos[key];
      let divProducto = document.createElement("div");
      divProducto.className = "producto-card";
      divProducto.setAttribute("data-categoria", prod.categoria);

      const stockTexto =
        prod.stock > 0
          ? `Stock: ${prod.stock}`
          : '<span class="agotado">AGOTADO</span>';
      const ofertaBadge = prod.enOferta
        ? '<span class="oferta-badge">🔥 OFERTA</span>'
        : "";

      divProducto.innerHTML = `
        <h3>${prod.nombre} ${ofertaBadge}</h3>
        <p class="precio">€${prod.precio.toFixed(2)}</p>
        <p><strong>Categoría:</strong> ${prod.categoria}</p>
        <p><strong>Stock:</strong> ${stockTexto}</p>
        <p><strong>Fecha:</strong> ${prod.fechaCreacion}</p>
      `;

      const checkboxContainer = document.createElement("div");
      checkboxContainer.className = "checkbox-container";

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = prod.enOferta;
      checkbox.addEventListener("change", () => {
        window.ProductManager.toggleOferta(prod.id);
      });

      const labelCheckbox = document.createElement("label");
      labelCheckbox.appendChild(checkbox);
      labelCheckbox.appendChild(document.createTextNode(" En Oferta"));

      checkboxContainer.appendChild(labelCheckbox);

      const btnEliminar = document.createElement("button");
      btnEliminar.textContent = "🗑️ Eliminar";
      btnEliminar.className = "btn-eliminar";
      btnEliminar.addEventListener("click", () => {
        if (confirm(`¿Eliminar ${prod.nombre}?`)) {
          window.ProductManager.eliminarProducto(prod.id);
        }
      });

      divProducto.appendChild(checkboxContainer);
      divProducto.appendChild(btnEliminar);
      visualizadorProductos.appendChild(divProducto);
    }
  }

  static obtenerDatos() {
    const nombre = document.getElementById("nombreProducto").value;
    const precio = parseFloat(document.getElementById("precioProducto").value);
    const categoria = document.getElementById("categoriaProducto").value;
    const stock = parseInt(document.getElementById("stockProducto").value);

    return { nombre, precio, categoria, stock };
  }

  static obtenerFiltroCategoria() {
    return document.getElementById("filtroCategoria").value;
  }

  static obtenerFiltroStock() {
    return document.getElementById("filtroStock").value;
  }

  static obtenerFiltroOferta() {
    return document.getElementById("filtroOferta").value;
  }

  static obtenerTextoBusqueda() {
    return document.getElementById("buscador").value;
  }

  static limpiarFormulario() {
    document.getElementById("nombreProducto").value = "";
    document.getElementById("precioProducto").value = "";
    document.getElementById("categoriaProducto").value = "electronica";
    document.getElementById("stockProducto").value = "";
  }
}
