export class Producto {
  constructor(nombre, precio, categoria, stock) {
    this.id = Date.now();
    this.nombre = nombre;
    this.precio = precio;
    this.categoria = categoria;
    this.stock = stock;
    this.enOferta = false;
    this.fechaCreacion = new Date().toLocaleDateString();
  }
}
