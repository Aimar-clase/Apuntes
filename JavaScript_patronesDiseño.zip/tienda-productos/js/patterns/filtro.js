export class Filtro {
  constructor() {
    this.strategy = null;
  }

  setStrategy(strategy) {
    this.strategy = strategy;
  }

  filtrar(productos, valor) {
    if (!this.strategy) {
      return productos;
    }
    return this.strategy.filtrar(productos, valor);
  }
}

export class FiltrarPorCategoria {
  filtrar(productos, categoria) {
    if (!productos || productos.length === 0) {
      return [];
    }
    return productos.filter((producto) => producto.categoria === categoria);
  }
}

export class FiltrarPorStock {
  filtrar(productos, estado) {
    if (!productos || productos.length === 0) {
      return [];
    }
    if (estado === "disponible") {
      return productos.filter((producto) => producto.stock > 0);
    } else if (estado === "agotado") {
      return productos.filter((producto) => producto.stock === 0);
    }
    return productos;
  }
}

export class FiltrarPorOferta {
  filtrar(productos, estado) {
    if (!productos || productos.length === 0) {
      return [];
    }
    if (estado === "oferta") {
      return productos.filter((producto) => producto.enOferta === true);
    } else if (estado === "sinOferta") {
      return productos.filter((producto) => producto.enOferta === false);
    }
    return productos;
  }
}

export class MostrarTodos {
  filtrar(productos) {
    return productos || [];
  }
}

export class BuscarPorTexto {
  filtrar(productos, texto) {
    if (!productos || productos.length === 0) {
      return [];
    }
    const textoBusqueda = texto.toLowerCase();
    return productos.filter(
      (producto) =>
        producto.nombre.toLowerCase().includes(textoBusqueda) ||
        producto.categoria.toLowerCase().includes(textoBusqueda)
    );
  }
}
