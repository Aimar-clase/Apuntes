import { DomFacade } from "../domFacade.js";
import { Producto } from "../models/producto.js";
import { Almacenamiento } from "../storage/localStorage.js";
import {
  Filtro,
  FiltrarPorCategoria,
  FiltrarPorStock,
  FiltrarPorOferta,
  MostrarTodos,
  BuscarPorTexto,
} from "./filtro.js";

export class ProductManager {
  static crearProducto(event) {
    event.preventDefault();

    const errores = [];
    const datosProducto = DomFacade.obtenerDatos();

    if (datosProducto.nombre === "") {
      errores.push("El nombre no puede estar vacío");
    }
    if (datosProducto.precio <= 0) {
      errores.push("El precio debe ser mayor a 0");
    }
    if (datosProducto.stock < 0) {
      errores.push("El stock no puede ser negativo");
    }

    if (errores.length === 0) {
      const producto = new Producto(
        datosProducto.nombre,
        datosProducto.precio,
        datosProducto.categoria,
        datosProducto.stock
      );
      Almacenamiento.addLocalStorage(producto);
      DomFacade.limpiarFormulario();
      ProductManager.renderProductos();
    } else {
      alert(errores.join("\n"));
    }
  }

  static renderProductos() {
    DomFacade.crearProductoDom(Almacenamiento.obtener());
  }

  static filtrarPorCategoria() {
    const categoria = DomFacade.obtenerFiltroCategoria();
    const todosLosProductos = Almacenamiento.obtener();

    const filtro = new Filtro();

    if (categoria === "" || categoria === "todas") {
      filtro.setStrategy(new MostrarTodos());
      DomFacade.crearProductoDom(filtro.filtrar(todosLosProductos));
    } else {
      filtro.setStrategy(new FiltrarPorCategoria());
      DomFacade.crearProductoDom(filtro.filtrar(todosLosProductos, categoria));
    }
  }

  static filtrarPorStock() {
    const stock = DomFacade.obtenerFiltroStock();
    const todosLosProductos = Almacenamiento.obtener();

    const filtro = new Filtro();

    if (stock === "" || stock === "todos") {
      filtro.setStrategy(new MostrarTodos());
      DomFacade.crearProductoDom(filtro.filtrar(todosLosProductos));
    } else {
      filtro.setStrategy(new FiltrarPorStock());
      DomFacade.crearProductoDom(filtro.filtrar(todosLosProductos, stock));
    }
  }

  static filtrarPorOferta() {
    const oferta = DomFacade.obtenerFiltroOferta();
    const todosLosProductos = Almacenamiento.obtener();

    const filtro = new Filtro();

    if (oferta === "" || oferta === "todos") {
      filtro.setStrategy(new MostrarTodos());
      DomFacade.crearProductoDom(filtro.filtrar(todosLosProductos));
    } else {
      filtro.setStrategy(new FiltrarPorOferta());
      DomFacade.crearProductoDom(filtro.filtrar(todosLosProductos, oferta));
    }
  }

  static buscarProducto() {
    const textoBusqueda = DomFacade.obtenerTextoBusqueda();
    const todosLosProductos = Almacenamiento.obtener();

    const filtro = new Filtro();

    if (textoBusqueda === "") {
      filtro.setStrategy(new MostrarTodos());
      DomFacade.crearProductoDom(filtro.filtrar(todosLosProductos));
    } else {
      filtro.setStrategy(new BuscarPorTexto());
      DomFacade.crearProductoDom(
        filtro.filtrar(todosLosProductos, textoBusqueda)
      );
    }
  }

  static toggleOferta(id) {
    const productos = Almacenamiento.obtener();
    const producto = productos.find((p) => p.id === id);

    if (producto) {
      producto.enOferta = !producto.enOferta;
      localStorage.setItem("productos", JSON.stringify(productos));
      ProductManager.renderProductos();
    }
  }

  static eliminarProducto(id) {
    const productos = Almacenamiento.obtener();
    const productosActualizados = productos.filter(
      (producto) => producto.id !== id
    );
    localStorage.setItem("productos", JSON.stringify(productosActualizados));
    ProductManager.renderProductos();
  }
}
