import { TaskManager } from "./patterns/taskManager.js";

const formulario = document.querySelector("form");
formulario.addEventListener("submit", TaskManager.crearTarea);

document.addEventListener("DOMContentLoaded", TaskManager.renderTarea);

const filtroPrioridad = document.getElementById("filtroPrioridad");
filtroPrioridad.addEventListener("change", TaskManager.filtrarPorPrioridad);

const filtroEstado = document.getElementById("filtroEstado");
filtroEstado.addEventListener("change", TaskManager.filtrarPorEstado);

const buscador = document.getElementById("buscador");
buscador.addEventListener("input", TaskManager.buscarTarea);

window.TaskManager = TaskManager;
