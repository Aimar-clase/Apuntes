export class DomFacade {
  static crearTareaDom(tareas) {
    const visualizadorTareas = document.getElementById("visualizadorTareas");
    visualizadorTareas.innerHTML = "";

    if (!tareas || tareas.length === 0) {
      visualizadorTareas.innerHTML = "<p>No hay tareas para mostrar</p>";
      return;
    }

    for (const key in tareas) {
      let tar = tareas[key];
      let divTarea = document.createElement("div");
      divTarea.className = "tarea-card";
      divTarea.setAttribute("data-prioridad", tar.prioridad);

      divTarea.innerHTML = `
        <h3>${tar.titulo}</h3>
        <p><strong>Descripción:</strong> ${tar.descripcion}</p>
        <p><strong>Prioridad:</strong> ${tar.prioridad}</p>
        <p><strong>Fecha:</strong> ${tar.createdAt}</p>
        <p><strong>Estado:</strong> ${
          tar.done ? "✅ Completada" : "⏳ Pendiente"
        }</p>
      `;

      const checkboxContainer = document.createElement("div");
      checkboxContainer.className = "checkbox-container";

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = tar.done;
      checkbox.addEventListener("change", () => {
        window.TaskManager.toggleEstado(tar.id);
      });

      checkboxContainer.appendChild(checkbox);
      checkboxContainer.appendChild(document.createTextNode(" Completada"));

      const btnEliminar = document.createElement("button");
      btnEliminar.textContent = "🗑️ Eliminar";
      btnEliminar.className = "btn-eliminar";
      btnEliminar.addEventListener("click", () => {
        if (confirm(`¿Eliminar la tarea "${tar.titulo}"?`)) {
          window.TaskManager.eliminarTarea(tar.id);
        }
      });

      divTarea.appendChild(checkboxContainer);
      divTarea.appendChild(btnEliminar);
      visualizadorTareas.appendChild(divTarea);
    }
  }

  static obtenerDatos() {
    const tituloTarea = document.getElementById("tituloTarea").value;
    const descripcionTarea = document.getElementById("descripcionTarea").value;
    const prioridadTarea = document.getElementById("prioridadTarea").value;
    return { tituloTarea, descripcionTarea, prioridadTarea };
  }

  static obtenerPrioridad() {
    return document.getElementById("filtroPrioridad").value;
  }

  static obtenerEstado() {
    return document.getElementById("filtroEstado").value;
  }

  static obtenerTextoBusqueda() {
    return document.getElementById("buscador").value;
  }

  static limpiarFormulario() {
    document.getElementById("tituloTarea").value = "";
    document.getElementById("descripcionTarea").value = "";
    document.getElementById("prioridadTarea").value = "normal";
  }
}
