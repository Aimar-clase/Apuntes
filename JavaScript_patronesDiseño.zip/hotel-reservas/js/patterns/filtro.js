export class Filtro {
  constructor() {
    this.strategy = null;
  }

  setStrategy(strategy) {
    this.strategy = strategy;
  }

  filtrar(reservas, valor) {
    if (!this.strategy) {
      return reservas;
    }
    return this.strategy.filtrar(reservas, valor);
  }
}

export class FiltrarPorTipo {
  filtrar(reservas, tipo) {
    if (!reservas || reservas.length === 0) {
      return [];
    }
    return reservas.filter((reserva) => reserva.tipoHabitacion === tipo);
  }
}

export class FiltrarPorEstado {
  filtrar(reservas, estado) {
    if (!reservas || reservas.length === 0) {
      return [];
    }
    if (estado === "confirmada") {
      return reservas.filter((reserva) => reserva.confirmada === true);
    } else if (estado === "cancelada") {
      return reservas.filter((reserva) => reserva.confirmada === false);
    }
    return reservas;
  }
}

export class FiltrarPorPrecio {
  filtrar(reservas, rango) {
    if (!reservas || reservas.length === 0) {
      return [];
    }
    if (rango === "economico") {
      return reservas.filter((reserva) => reserva.precioTotal < 300);
    } else if (rango === "medio") {
      return reservas.filter(
        (reserva) => reserva.precioTotal >= 300 && reserva.precioTotal <= 600
      );
    } else if (rango === "premium") {
      return reservas.filter((reserva) => reserva.precioTotal > 600);
    }
    return reservas;
  }
}

export class MostrarTodas {
  filtrar(reservas) {
    return reservas || [];
  }
}

export class BuscarPorTexto {
  filtrar(reservas, texto) {
    if (!reservas || reservas.length === 0) {
      return [];
    }
    const textoBusqueda = texto.toLowerCase();
    return reservas.filter(
      (reserva) =>
        reserva.nombreCliente.toLowerCase().includes(textoBusqueda) ||
        reserva.email.toLowerCase().includes(textoBusqueda) ||
        reserva.telefono.toLowerCase().includes(textoBusqueda) ||
        reserva.tipoHabitacion.toLowerCase().includes(textoBusqueda)
    );
  }
}
