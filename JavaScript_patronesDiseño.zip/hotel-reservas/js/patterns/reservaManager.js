import { DomFacade } from "../domFacade.js";
import { Reserva } from "../models/reserva.js";
import { Almacenamiento } from "../storage/localStorage.js";
import {
  Filtro,
  FiltrarPorTipo,
  FiltrarPorEstado,
  FiltrarPorPrecio,
  MostrarTodas,
  BuscarPorTexto,
} from "./filtro.js";

export class ReservaManager {
  static crearReserva(event) {
    event.preventDefault();

    const errores = [];
    const datosReserva = DomFacade.obtenerDatos();

    if (datosReserva.nombreCliente === "") {
      errores.push("El nombre del cliente no puede estar vacío");
    }
    if (datosReserva.email === "" || !datosReserva.email.includes("@")) {
      errores.push("El email debe ser válido");
    }
    if (datosReserva.telefono === "") {
      errores.push("El teléfono no puede estar vacío");
    }
    if (datosReserva.noches <= 0) {
      errores.push("El número de noches debe ser mayor a 0");
    }
    if (datosReserva.precioNoche <= 0) {
      errores.push("El precio por noche debe ser mayor a 0");
    }

    if (errores.length === 0) {
      const reserva = new Reserva(
        datosReserva.nombreCliente,
        datosReserva.email,
        datosReserva.telefono,
        datosReserva.tipoHabitacion,
        datosReserva.noches,
        datosReserva.precioNoche
      );
      Almacenamiento.addLocalStorage(reserva);
      DomFacade.limpiarFormulario();
      ReservaManager.renderReservas();
    } else {
      alert(errores.join("\n"));
    }
  }

  static renderReservas() {
    DomFacade.crearReservaDom(Almacenamiento.obtener());
  }

  static filtrarPorTipo() {
    const tipo = DomFacade.obtenerFiltroTipo();
    const todasLasReservas = Almacenamiento.obtener();

    const filtro = new Filtro();

    if (tipo === "" || tipo === "todas") {
      filtro.setStrategy(new MostrarTodas());
      DomFacade.crearReservaDom(filtro.filtrar(todasLasReservas));
    } else {
      filtro.setStrategy(new FiltrarPorTipo());
      DomFacade.crearReservaDom(filtro.filtrar(todasLasReservas, tipo));
    }
  }

  static filtrarPorEstado() {
    const estado = DomFacade.obtenerFiltroEstado();
    const todasLasReservas = Almacenamiento.obtener();

    const filtro = new Filtro();

    if (estado === "" || estado === "todas") {
      filtro.setStrategy(new MostrarTodas());
      DomFacade.crearReservaDom(filtro.filtrar(todasLasReservas));
    } else {
      filtro.setStrategy(new FiltrarPorEstado());
      DomFacade.crearReservaDom(filtro.filtrar(todasLasReservas, estado));
    }
  }

  static filtrarPorPrecio() {
    const precio = DomFacade.obtenerFiltroPrecio();
    const todasLasReservas = Almacenamiento.obtener();

    const filtro = new Filtro();

    if (precio === "" || precio === "todos") {
      filtro.setStrategy(new MostrarTodas());
      DomFacade.crearReservaDom(filtro.filtrar(todasLasReservas));
    } else {
      filtro.setStrategy(new FiltrarPorPrecio());
      DomFacade.crearReservaDom(filtro.filtrar(todasLasReservas, precio));
    }
  }

  static buscarReserva() {
    const textoBusqueda = DomFacade.obtenerTextoBusqueda();
    const todasLasReservas = Almacenamiento.obtener();

    const filtro = new Filtro();

    if (textoBusqueda === "") {
      filtro.setStrategy(new MostrarTodas());
      DomFacade.crearReservaDom(filtro.filtrar(todasLasReservas));
    } else {
      filtro.setStrategy(new BuscarPorTexto());
      DomFacade.crearReservaDom(
        filtro.filtrar(todasLasReservas, textoBusqueda)
      );
    }
  }

  static toggleConfirmacion(id) {
    const reservas = Almacenamiento.obtener();
    const reserva = reservas.find((r) => r.id === id);

    if (reserva) {
      reserva.confirmada = !reserva.confirmada;
      localStorage.setItem("reservas", JSON.stringify(reservas));
      ReservaManager.renderReservas();
    }
  }

  static eliminarReserva(id) {
    const reservas = Almacenamiento.obtener();
    const reservasActualizadas = reservas.filter(
      (reserva) => reserva.id !== id
    );
    localStorage.setItem("reservas", JSON.stringify(reservasActualizadas));
    ReservaManager.renderReservas();
  }
}
