export class DomFacade {
  static crearReservaDom(reservas) {
    const visualizadorReservas = document.getElementById(
      "visualizadorReservas"
    );
    visualizadorReservas.innerHTML = "";

    if (!reservas || reservas.length === 0) {
      visualizadorReservas.innerHTML = "<p>No hay reservas registradas</p>";
      return;
    }

    for (const key in reservas) {
      let res = reservas[key];
      let divReserva = document.createElement("div");
      divReserva.className = "reserva-card";
      divReserva.setAttribute("data-tipo", res.tipoHabitacion);

      const estadoBadge = res.confirmada
        ? '<span class="confirmada-badge">✅ Confirmada</span>'
        : '<span class="cancelada-badge">❌ Cancelada</span>';

      divReserva.innerHTML = `
        <h3>📋 Reserva #${res.id}</h3>
        <p><strong>👤 Cliente:</strong> ${res.nombreCliente}</p>
        <p><strong>📧 Email:</strong> ${res.email}</p>
        <p><strong>📞 Teléfono:</strong> ${res.telefono}</p>
        <p><strong>🏨 Habitación:</strong> ${res.tipoHabitacion}</p>
        <p><strong>🌙 Noches:</strong> ${res.noches}</p>
        <p><strong>💵 Precio/Noche:</strong> €${res.precioNoche}</p>
        <p class="precio-total"><strong>💰 Total:</strong> €${res.precioTotal}</p>
        <p><strong>📅 Fecha:</strong> ${res.fechaReserva}</p>
        <p><strong>Estado:</strong> ${estadoBadge}</p>
      `;

      const checkboxContainer = document.createElement("div");
      checkboxContainer.className = "checkbox-container";

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = res.confirmada;
      checkbox.addEventListener("change", () => {
        window.ReservaManager.toggleConfirmacion(res.id);
      });

      checkboxContainer.appendChild(checkbox);
      checkboxContainer.appendChild(
        document.createTextNode(" Reserva Confirmada")
      );

      const btnEliminar = document.createElement("button");
      btnEliminar.textContent = "🗑️ Eliminar Reserva";
      btnEliminar.className = "btn-eliminar";
      btnEliminar.addEventListener("click", () => {
        if (confirm(`¿Eliminar la reserva de ${res.nombreCliente}?`)) {
          window.ReservaManager.eliminarReserva(res.id);
        }
      });

      divReserva.appendChild(checkboxContainer);
      divReserva.appendChild(btnEliminar);
      visualizadorReservas.appendChild(divReserva);
    }
  }

  static obtenerDatos() {
    const nombreCliente = document.getElementById("nombreCliente").value;
    const email = document.getElementById("emailCliente").value;
    const telefono = document.getElementById("telefonoCliente").value;
    const tipoHabitacion = document.getElementById("tipoHabitacion").value;
    const noches = parseInt(document.getElementById("noches").value);
    const precioNoche = parseFloat(
      document.getElementById("precioNoche").value
    );

    return {
      nombreCliente,
      email,
      telefono,
      tipoHabitacion,
      noches,
      precioNoche,
    };
  }

  static obtenerFiltroTipo() {
    return document.getElementById("filtroTipo").value;
  }

  static obtenerFiltroEstado() {
    return document.getElementById("filtroEstado").value;
  }

  static obtenerFiltroPrecio() {
    return document.getElementById("filtroPrecio").value;
  }

  static obtenerTextoBusqueda() {
    return document.getElementById("buscador").value;
  }

  static limpiarFormulario() {
    document.getElementById("nombreCliente").value = "";
    document.getElementById("emailCliente").value = "";
    document.getElementById("telefonoCliente").value = "";
    document.getElementById("tipoHabitacion").value = "individual";
    document.getElementById("noches").value = "";
    document.getElementById("precioNoche").value = "";
  }
}
