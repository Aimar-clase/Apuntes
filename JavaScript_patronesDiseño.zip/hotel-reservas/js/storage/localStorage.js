export class Almacenamiento {
  static obtener() {
    return JSON.parse(localStorage.getItem("reservas"));
  }

  static addLocalStorage(reserva) {
    let reservas = this.obtener() || [];
    reservas.push(reserva);
    localStorage.setItem("reservas", JSON.stringify(reservas));
  }
}
