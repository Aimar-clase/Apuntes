import { ReservaManager } from "./patterns/reservaManager.js";

const formulario = document.querySelector("form");
formulario.addEventListener("submit", ReservaManager.crearReserva);

document.addEventListener("DOMContentLoaded", ReservaManager.renderReservas);

const filtroTipo = document.getElementById("filtroTipo");
filtroTipo.addEventListener("change", ReservaManager.filtrarPorTipo);

const filtroEstado = document.getElementById("filtroEstado");
filtroEstado.addEventListener("change", ReservaManager.filtrarPorEstado);

const filtroPrecio = document.getElementById("filtroPrecio");
filtroPrecio.addEventListener("change", ReservaManager.filtrarPorPrecio);

const buscador = document.getElementById("buscador");
buscador.addEventListener("input", ReservaManager.buscarReserva);

window.ReservaManager = ReservaManager;
