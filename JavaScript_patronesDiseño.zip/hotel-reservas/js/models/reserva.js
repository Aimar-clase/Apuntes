export class Reserva {
  constructor(
    nombreCliente,
    email,
    telefono,
    tipoHabitacion,
    noches,
    precioNoche
  ) {
    this.id = Date.now();
    this.nombreCliente = nombreCliente;
    this.email = email;
    this.telefono = telefono;
    this.tipoHabitacion = tipoHabitacion;
    this.noches = noches;
    this.precioNoche = precioNoche;
    this.precioTotal = noches * precioNoche;
    this.confirmada = true;
    this.fechaReserva = new Date().toLocaleDateString();
  }

  calcularPrecioTotal() {
    return this.noches * this.precioNoche;
  }
}
