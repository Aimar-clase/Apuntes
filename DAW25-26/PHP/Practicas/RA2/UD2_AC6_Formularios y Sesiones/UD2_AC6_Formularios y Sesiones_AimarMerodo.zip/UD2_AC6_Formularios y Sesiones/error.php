<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Error</title>

    <link rel="stylesheet" href="styles.css">
</head>
<body class="vh-body">
<h1 class="vh-title">ERROR</h1>
</body>
</html>
